plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "uz.sakura.livewallpaper"
    compileSdk = 35
    defaultConfig {
        applicationId = "uz.sakura.livewallpaper"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
