package uz.sakura.livewallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "Sakura Jonli Oboy"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Ikki xil rang uslubi bor. Tanlaganingiz keyin jonli oboyda ko‘rinadi."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 20)
        }
        val warm = Button(this).apply {
            text = "1. Iliq quyoshli ranglar"
            setOnClickListener {
                getSharedPreferences("sakura", MODE_PRIVATE).edit().putInt("style", 0).apply()
                openWallpaperPicker()
            }
        }
        val cool = Button(this).apply {
            text = "2. Tiniq ko‘k-suv ranglar"
            setOnClickListener {
                getSharedPreferences("sakura", MODE_PRIVATE).edit().putInt("style", 1).apply()
                openWallpaperPicker()
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(warm)
        layout.addView(cool)
        setContentView(layout)
    }

    private fun openWallpaperPicker() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this@MainActivity, SakuraWallpaperService::class.java))
        }
        startActivity(intent)
    }
}
