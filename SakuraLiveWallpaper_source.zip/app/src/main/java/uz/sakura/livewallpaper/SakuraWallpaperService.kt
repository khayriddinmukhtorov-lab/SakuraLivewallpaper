package uz.sakura.livewallpaper

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import kotlin.math.sin

class SakuraWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = SakuraEngine()

    inner class SakuraEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var phase = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val drawTask = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 80L)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(drawTask)
            if (visible) handler.post(drawTask)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(drawTask)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun render(c: Canvas) {
            val w = c.width.toFloat()
            val h = c.height.toFloat()
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val style = getSharedPreferences("sakura", MODE_PRIVATE).getInt("style", 0)
            val night = hour < 6 || hour >= 21
            val dawn = hour in 5..8
            val evening = hour in 17..20

            val top: Int
            val bottom: Int
            if (night) {
                top = Color.rgb(8, 20, 55); bottom = Color.rgb(35, 55, 90)
            } else if (dawn || evening) {
                top = if (style == 0) Color.rgb(255, 155, 115) else Color.rgb(115, 170, 220)
                bottom = if (style == 0) Color.rgb(255, 220, 155) else Color.rgb(185, 220, 235)
            } else {
                top = if (style == 0) Color.rgb(95, 175, 235) else Color.rgb(45, 145, 205)
                bottom = if (style == 0) Color.rgb(210, 235, 245) else Color.rgb(155, 220, 230)
            }
            paint.shader = LinearGradient(0f, 0f, 0f, h * .72f, top, bottom, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null

            // Moon or sun follows the real time.
            paint.color = if (night) Color.rgb(235, 240, 255) else Color.rgb(255, 220, 105)
            val sunX = w * (0.18f + ((hour % 12) / 12f) * .64f)
            val sunY = if (night) h * .17f else h * .22f
            c.drawCircle(sunX, sunY, w * .055f, paint)
            if (night) {
                paint.color = Color.WHITE
                for (i in 0..26) {
                    val x = ((i * 73) % 997) / 997f * w
                    val y = ((i * 47) % 487) / 700f * h
                    c.drawCircle(x, y, if (i % 3 == 0) 2.2f else 1.2f, paint)
                }
            }

            // Mountain silhouettes
            paint.color = Color.rgb(65, 105, 125)
            val mountain = android.graphics.Path().apply {
                moveTo(0f, h*.52f); lineTo(w*.23f, h*.28f); lineTo(w*.42f, h*.51f)
                lineTo(w*.64f, h*.32f); lineTo(w*.88f, h*.53f); lineTo(w, h*.43f)
                lineTo(w, h*.72f); lineTo(0f, h*.72f); close()
            }
            c.drawPath(mountain, paint)

            // Sakura tree trunk and branches
            paint.color = Color.rgb(70, 55, 43)
            paint.strokeWidth = w * .025f
            c.drawLine(w*.12f, h*.69f, w*.19f, h*.35f, paint)
            c.drawLine(w*.17f, h*.48f, w*.04f, h*.37f, paint)
            c.drawLine(w*.16f, h*.44f, w*.31f, h*.32f, paint)
            c.drawLine(w*.17f, h*.54f, w*.34f, h*.47f, paint)
            paint.strokeWidth = 1f
            val blossom = if (night) Color.rgb(180, 135, 195) else Color.rgb(255, 170, 200)
            paint.color = blossom
            for (i in 0..34) {
                val x = w*(.04f + ((i*37)%310)/1000f)
                val y = h*(.29f + ((i*29)%240)/1000f)
                c.drawCircle(x, y, w*.025f, paint)
            }

            // River with animated ripples
            paint.color = if (night) Color.rgb(35, 75, 125) else if (style == 0) Color.rgb(55, 165, 195) else Color.rgb(35, 135, 190)
            val river = android.graphics.Path().apply {
                moveTo(w*.42f, h*.53f); lineTo(w*.66f, h*.53f); lineTo(w, h)
                lineTo(0f, h); close()
            }
            c.drawPath(river, paint)
            paint.color = if (night) Color.rgb(180, 195, 225) else Color.rgb(220, 245, 240)
            paint.strokeWidth = 2.5f
            for (i in 0..14) {
                val y = h*(.62f + i*.025f)
                val x = w*(.16f + ((i*31)%70)/100f) + sin(phase + i)*w*.012f
                c.drawLine(x, y, x+w*(.08f + (i%3)*.02f), y, paint)
            }

            // Small birds moving across the sky
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.4f
            paint.color = if (night) Color.LTGRAY else Color.rgb(45, 45, 48)
            for (i in 0..3) {
                val x = ((phase*22 + i* w*.27f) % (w+60f)) - 30f
                val y = h*(.20f + i*.045f)
                c.drawArc(x, y, x+14f, y+10f, 200f, 140f, false, paint)
                c.drawArc(x+12f, y, x+26f, y+10f, 200f, 140f, false, paint)
            }
            paint.style = Paint.Style.FILL
            phase += .08f
        }
    }
}
