# Sakura Jonli Oboy — boshlang‘ich Android loyiha

Bu loyiha Samsung Galaxy S23 uchun Android Studio’da ochiladigan manba-kod namunasi.

## Ichida nima bor?
- Ikki rang uslubi: iliq quyoshli va tiniq ko‘k-suv rang.
- Soatga qarab osmon rangining tong/kunduz/kech/tun ko‘rinishiga o‘zgarishi.
- Harakatlanadigan qushlar va daryo yuzasidagi yaltirash chiziqlari.
- Sakura daraxti, tog‘lar, quyosh yoki oy va yulduzlar.

## Muhim
Bu **tayyor APK emas**, Android Studio’da build qilish kerak bo‘lgan manba-kod loyihasi. Bu ilk prototip: haqiqiy 3D kamera harakati va batafsil animatsiyali sakura yaproqlari hali qo‘shilmagan.

## APK tayyorlash
1. Kompyuterda Android Studio o‘rnating.
2. ZIP faylni ochib, `SakuraLiveWallpaper` papkasini Android Studio’da oching.
3. Gradle sync tugashini kuting.
4. Build → Build APK(s) ni bosing.
5. APK faylni telefoningizga ko‘chirib, o‘rnating.
6. Ilovani oching, rang uslubini tanlang va jonli oboyni qo‘llang.

Agar faqat telefon bo‘lsa, Android Studio’ni kompyutersiz ishlatish qiyinroq; keyingi bosqichda telefon orqali build qilish yo‘lini ko‘rib chiqish mumkin.
